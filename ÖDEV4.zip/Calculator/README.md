1. Aşağıdaki komutu çalıştırarak Docker imajınızı oluşturun:
    ```bash
    docker build -t calculator:1.0 .
2. Docker Compose ile konteyneri başlatın:
    ```bash
    docker-compose up -d